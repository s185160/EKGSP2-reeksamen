package ekggraphimp;

import javax.xml.transform.Result;
import java.sql.*;
import java.util.ArrayList;

public class DataBase extends Thread {

    Connection conn;
    String url;
    PreparedStatement prep;
    Statement stmt;
    String SQLQuery;
    Queue queue1, queue2;

    /**
     *
     * @param queue1
     * @param queue2
     */
    
    
    public DataBase(Queue queue1) {
        this.queue1 = queue1;
        String url = "jdbc:sqlite:/Users/Aliyah/sqlite/alia.db";
        try {
            Class.forName("org.sqlite.JDBC").newInstance();
            conn = DriverManager.getConnection(url);
            SQLQuery = " create table if not exists maalinger(id integer primary key, measurements double(2)); ";
            stmt = conn.createStatement();
            stmt.execute(SQLQuery);
            //System.out.println("A new database has been created.");
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    public synchronized void saveData(int[] input) {
        try {
            prep = conn.prepareStatement("insert into maalinger(measurements) values (?)");
            for (int i : input) {
                prep.setInt(1, i);
                prep.executeUpdate();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public synchronized ArrayList<Integer> getData() {
        ArrayList<Integer> output = new ArrayList<>();
        String search = "select * from maalinger LIMIT 900";
        try {
            stmt = conn.createStatement();
            ResultSet resultSet = stmt.executeQuery(search);
            while (resultSet.next()) {
                double getvalue = resultSet.getDouble(2);
                output.add((int) getvalue);
            }
            {
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        Buffer b = new Buffer();
        int[] outarray = new int[output.size()];
        for (int i = 0; i < outarray.length; i++) {
            outarray[i] = output.get(i);
            b.add(outarray[i]);
        }
        queue2.add(b);
        return output;
    }
}
