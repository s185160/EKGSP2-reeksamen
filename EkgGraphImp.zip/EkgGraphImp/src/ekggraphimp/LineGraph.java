/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ekggraphimp;
import java.awt.Graphics;
import java.awt.*;
import java.lang.*;
import java.util.*;
import java.text.*;
import java.awt.event.*;
//import java.awt.Frame;
public class LineGraph extends Frame 
{
String col1, title, dateStamp;
int line_number;
String y0val, y1val, x0val, x1val;
String yr0, yr1;
int x0 = 55;
int x1 = 475; 
int y0 = 100;
int y1 = 220; 
int ystep = 0;
String ycstg;
String xcstg;
float fxmin, fxmax, fymin, fymax;
int xmin, xmax, ymin, ymax, fxprev;
String hour[] = new String[24];
String hourvar;
int hourint;
int bpint;
int day1, month1, year1;
DateFormat dateFormatter;
float avgs[] = new float[24];
//input values are here

float hrs[] = new float[24];
int daysint;

public void paint(Graphics g) {


float bp[] = {2000, 0 , 5100, 4200, 8990};

Calendar cal = Calendar.getInstance();
Date date = cal.getTime();
dateFormatter = DateFormat.getDateInstance(DateFormat.FULL);
g.setColor(Color.black);
Color brush=new Color(240,240,255);
paintBackground(g,brush);
g.drawRect(x0,y0,x1,y1);
Font f=new Font("Helvetica",Font.PLAIN,30);
g.setFont(f);
g.drawString("",190,70);
Font subf0=new Font("Helvetica",Font.BOLD,15);
g.setFont(subf0);
g.drawString(dateFormatter.format(date),220,95);
Font subf1=new Font("Helvetica",Font.ITALIC,15);
g.setFont(subf1);
g.setColor(Color.black);
g.drawString("X-axis - Date",190,400);
g.drawString("Y-axis - Number of Sites",190,420);
// write y coordinates
Font fy=new Font("Helvetica",Font.PLAIN,10);
g.setFont(fy);
int ycadv = 320 ;
int ycint = 0; 

for (int j=0; j<=14; j++) {
ycstg = String.valueOf(ycint);
g.drawString(ycstg,25,ycadv);
g.drawString("_",45,ycadv);
ycint = ycint + 1000;
ycadv = ycadv - 15 ;
}
// write x coordinates
Font fx=new Font("Helvetica",Font.PLAIN,10);
g.setFont(fx );
int xcadv = 50 ;
float fxmin = 50;
String s_month;
String s_year;
int daysint = -7;// -2 align middle
/* day1 = day1 - daysint;*/
cal.add(cal.DAY_OF_MONTH, daysint);


for (int i=0; i<=4; i++) {

if ((i + 1) <= 4) {
fymin = bp[i];
fymax = bp[i+1];
}
cal.add(cal.DAY_OF_MONTH, 1);
day1=cal.get(cal.DAY_OF_MONTH);
month1=cal.get(cal.MONTH);
year1=cal.get(cal.YEAR);
s_month = String.valueOf(month1+1);
s_year = String.valueOf(year1);
xcstg = String.valueOf(day1+1);
g.drawString(s_month+"/"+xcstg+"/"+s_year,xcadv,335);
g.drawString("!",xcadv,325);
daysint = daysint + 1;

if ((i + 1) <= 4){
fymin = 320 - fymin * 15/1000;
fymax = 320 - fymax * 15/1000;
xcadv = xcadv + 75 ;
fxmax = xcadv;
// draw graph
/* Plot the lines */
g.drawLine((int) java.lang.Math.round(fxmin),
(int) java.lang.Math.round(fymin),
(int) java.lang.Math.round(fxmax),
(int) java.lang.Math.round(fymax));
fxmin = fxmax;
}
}
}

public void paintBackground(Graphics g, Color c_) {
Color c=g.getColor();
g.setColor(c_);
g.fillRect(x0,y0,x1,y1);
g.setColor(c); // Returns to original color
}

public static void main(String args[]){
Frame fr = new LineGraph();

WindowListener l = new WindowAdapter() {
public void windowClosing(WindowEvent e){ System.exit(0); }};
fr.addWindowListener(l);
fr.setSize(600, 450);
fr.show();
}
}