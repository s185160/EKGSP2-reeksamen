package ekggraphimp;

import jssc.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Sensor extends Thread {

    ArrayList<Integer> values = new ArrayList<>();
    private String inputfraport = "";
    SerialPort serialPort = null;
    Buffer b;
    int[] internbuffer;
    Queue queue;
    Painter painter;
    boolean isTrue = false;
    String rest = "";

    public Sensor(Queue q) {
        System.out.println("Sensor constructor Sensor(Queue q) - called");
        b = new Buffer();
        queue = q;
        serialPort = new SerialPort("/dev/tty.usbmodem1411");
        try {
            serialPort.openPort();// Open serial port
            serialPort.setParams(38400, 8, 1, 0);// Set params.
            serialPort.setFlowControlMode(SerialPort.FLOWCONTROL_NONE);
            serialPort.setDTR(true);
        } catch (SerialPortException ex) {
            System.out.println("Serial Port Exception: " + ex);
        }
        System.out.println("Sensor constructor Sensor(Queue q) - end");
    }

    @Override
    public void run() {
        System.out.println("ekgsensor.start() - called");
        try {
            Thread.sleep(100);
            
            serialPort.readString();
            while (true) {
                if (serialPort.getInputBufferBytesCount() > 0) {
                    inputfraport = rest + serialPort.readString();

                    //String res = inputfraport.substring(inputfraport.lastIndexOf(" "));

                    if(inputfraport.lastIndexOf(" ") < inputfraport.length()-1) {
                            rest = inputfraport.substring(inputfraport.lastIndexOf(" ")+1);
                    } else {
                        rest = "";
                    }
                    inputfraport = inputfraport.substring(0,inputfraport.lastIndexOf(" "));
                    System.out.println("Sensor data:" + inputfraport);
                    String[] splitstring = inputfraport.split(" ");
                    for (int i = 0; i < splitstring.length; i++) {
                        if (splitstring[i].length() > 0) {
                            if (Integer.parseInt(splitstring[i]) < 10) {
                                for (int j = i; j < splitstring.length - 1; j++) {
                                    splitstring[j] = splitstring[j + 1];
                                }
                                break;
                            } else {
                                isTrue = b.add(Integer.parseInt(splitstring[i]));
                                
                                if (isTrue) {
                                    queue.add(b);
                                System.out.println("Added Buffer to the Queue...");
                                    b = new Buffer();
                                }
                            }
                        }
                    }
                }
                //Thread.sleep(100);
            }
        } catch (Exception ex) {
            ex.getMessage();
            ex.printStackTrace();
        }
        System.out.println("ekgsensor.start() - end");
    }
}
