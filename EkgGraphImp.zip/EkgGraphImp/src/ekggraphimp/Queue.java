package ekggraphimp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Queue {

    ArrayList<Buffer> values = new ArrayList<Buffer>();
    Buffer b;
    private boolean empty = true;
    
    Painter p;

    public Queue(Buffer b) {
        this.b = b;
    }

    public synchronized void add(Buffer b) {
        System.out.println("Queue synchronized void add(Buffer b) - called");
        values.add(b);
        System.out.println("Current queue: "+Arrays.toString(values.toArray()));
        //p = new Painter(this);
        //p.run();
        
        notify();
        
        DataBase db = new DataBase(this);
        db.saveData(b.get());
        System.out.println("Queue synchronized void add(Buffer b) - end");
    }    
    public int[] GetValues() {
        int[] output = values.get(0).get();
        values.remove(0);
        return output;
    }
}
