
package ekggraphimp;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Stroke;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JPanel;

public class Painter extends JPanel implements Runnable {

    private int x0, y0, x1, y1;
    private int width = 800;
    private int heigth = 400;
    private int padding = 25;
    private int labelPadding = 25;
    private Color lineColor = new Color(13, 29, 230, 180);
    private Color pointColor = new Color(100, 100, 100, 180);
    private Color gridColor = new Color(200, 200, 200, 200);
    private static final Stroke GRAPH_STROKE = new BasicStroke(2f);
    private int pointWidth = 4;
    private int numberYDivisions = 10;
    private ArrayList<Integer> scoresArrayListInteger;
    private int xmax = 5000;
    Queue queueObj;
    private int[] fraqueueIntegerArray;
    public Painter(ArrayList values) {
        this.scoresArrayListInteger = values;
        System.out.println("Tegnepanel klar med startværdier ");
    }

    public Painter() {
        System.out.println("Tomt panel lavet, klar til fyld.");
    }
    public Painter(Queue q) {
        scoresArrayListInteger = new ArrayList();
        for (int i = 0; i < xmax; i++) {
            scoresArrayListInteger.add(0);
        }
        this.queueObj = q;
        //this.run();
        //revalidate();
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        double xScale = ((double) getWidth() - (2 * padding) - labelPadding) / (scoresArrayListInteger.size() - 1);
        double yScale = ((double) getHeight() - 2 * padding - labelPadding) / (getMaximumValuesIJeresDataSet() - getMinimumValuesIJeresDataSet());
        ArrayList<Point> punkter = new ArrayList<>();
        for (int i = 0; i < scoresArrayListInteger.size(); i++) {
            int x1 = (int) (i * xScale + padding + labelPadding);
            int y1 = (int) ((getMaximumValuesIJeresDataSet() - scoresArrayListInteger.get(i)) * yScale + padding);
            punkter.add(new Point(x1, y1));
        }
        g2.setColor(Color.WHITE);
        g2.fillRect(padding + labelPadding, padding, getWidth() - (2 * padding) - labelPadding, getHeight() - 2 * padding - labelPadding);
        g2.setColor(Color.BLACK);
        tegnGitterLinjerForXAksen(g2);
        tegnGitterLinjerForYAksen(g2);
        tegnAkserne(g2);
        Stroke oldStroke = g2.getStroke();
        g2.setColor(lineColor);
        g2.setStroke(GRAPH_STROKE);
        for (int i = 0; i < punkter.size() - 1; i++) {
            int x1 = punkter.get(i).x;
            int y1 = punkter.get(i).y;
            int x2 = punkter.get(i + 1).x;
            int y2 = punkter.get(i + 1).y;
            g2.drawLine(x1, y1, x2, y2);
        }
        g2.setStroke(oldStroke);
        g2.setColor(pointColor);
        for (int i = 0; i < punkter.size(); i++) {
            int x = punkter.get(i).x - pointWidth / 2;
            int y = punkter.get(i).y - pointWidth / 2;
            int ovalW = pointWidth;
            int ovalH = pointWidth;
            g2.fillOval(x, y, ovalW, ovalH);
        }
        tegnGraf(g2, punkter);
    }

    private void tegnGraf(Graphics2D g2, ArrayList punkter) {
    }

    private void tegnAkserne(Graphics2D g2) {
        g2.drawLine(padding + labelPadding, getHeight() - padding - labelPadding, padding + labelPadding, padding);
        g2.drawLine(padding + labelPadding, getHeight() - padding - labelPadding, getWidth() - padding, getHeight() - padding - labelPadding);
    }

    public void updateValues(ArrayList maalinger) {
        this.scoresArrayListInteger = maalinger;
        //invalidate();
        this.repaint();
    }

    public void tilfoejEnkeltVaerdi(int vaerdi) {
        scoresArrayListInteger.add(vaerdi);
        this.repaint();
    }

    public ArrayList<Integer> getScores() {
        return scoresArrayListInteger;
    }

    private void tegnGitterLinjerForYAksen(Graphics2D g2) {
        for (int i = 0; i < numberYDivisions + 1; i++) {
            int x0 = padding + labelPadding;
            int x1 = pointWidth + padding + labelPadding;
            int y0 = getHeight() - ((i * (getHeight() - padding * 2 - labelPadding)) / numberYDivisions + padding + labelPadding);
            int y1 = y0;
            if (scoresArrayListInteger.size() > 0) {
                g2.setColor(gridColor);
                g2.drawLine(padding + labelPadding + 1 + pointWidth, y0, getWidth() - padding, y1);
                g2.setColor(Color.BLACK);
                String yLabel = ((int) ((getMinimumValuesIJeresDataSet() + (getMaximumValuesIJeresDataSet() - getMinimumValuesIJeresDataSet()) * ((i * 1.0) / numberYDivisions)) * 100)) / 100.0 + "";
                FontMetrics metrics = g2.getFontMetrics();
                int labelWidth = metrics.stringWidth(yLabel);
                g2.drawString(yLabel, x0 - labelWidth - 5, y0 + (metrics.getHeight() / 2) - 3);
            }
            g2.drawLine(x0, y0, x1, y1);
        }
    }

    private void tegnGitterLinjerForXAksen(Graphics2D g2) {
        for (int i = 0; i < scoresArrayListInteger.size(); i++) {
            if (scoresArrayListInteger.size() > 1) {
                int x0 = i * (getWidth() - padding * 2 - labelPadding) / (scoresArrayListInteger.size() - 1) + padding + labelPadding;
                int x1 = x0;
                int y0 = getHeight() - padding - labelPadding;
                int y1 = y0 - pointWidth;
                if ((i % ((int) ((scoresArrayListInteger.size() / 20.0)) + 1)) == 0) {
                    g2.setColor(gridColor);
                    g2.drawLine(x0, getHeight() - padding - labelPadding - 1 - pointWidth, x1, padding);
                    g2.setColor(Color.BLACK);
                    String xLabel = i + "";
                    FontMetrics metrics = g2.getFontMetrics();
                    int labelWidth = metrics.stringWidth(xLabel);
                    g2.drawString(xLabel, x0 - labelWidth / 2, y0 + metrics.getHeight() + 3);
                }
                g2.drawLine(x0, y0, x1, y1);
            }
        }
    }

    private double getMinimumValuesIJeresDataSet() {
        double minScore = Double.MAX_VALUE;
        for (int score : scoresArrayListInteger) {
            minScore = Math.min(minScore, score);
        }
        return minScore;
    }

    private double getMaximumValuesIJeresDataSet() {
        double maxScore = Double.MIN_VALUE;
        for (int score : scoresArrayListInteger) {
            maxScore = Math.max(maxScore, score);
        }
        return maxScore;
    }
    int counter = 0;

    @Override
    public void run() {
        
        scoresArrayListInteger.clear();
        if(!queueObj.values.isEmpty()){

        fraqueueIntegerArray = queueObj.GetValues();
        for (int i : fraqueueIntegerArray) {
            scoresArrayListInteger.add(i);
            System.out.println("Graf-array: " + Arrays.toString(fraqueueIntegerArray));
            counter++;
        }
        
        //updateValues(scoresArrayListInteger);
        if (counter == 1200) {
            counter = 0;
        }
        
        updateValues(scoresArrayListInteger);
        
        //invalidate();
        //repaint();
        }else{
            System.out.println("Wait untill the queue is filled");
        }
    }
}
