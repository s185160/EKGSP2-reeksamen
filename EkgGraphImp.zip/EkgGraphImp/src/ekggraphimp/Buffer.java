package ekggraphimp;

import ekggraphimp.Queue;
import java.util.ArrayList;
import java.util.Arrays;

//------------------------------------------------------------------------------
public class Buffer {

    private int[] sensorData = new int[300];
    
    private Queue queue;
    private int count = 0;
    

    public boolean add(int number) {
        sensorData[count] = number;
        boolean isfull = false;
        count++;
        if (count >= sensorData.length) {
            isfull = true;
            System.out.print("Buffer array: ");
            System.out.println(Arrays.toString(sensorData));
            count = 0;
        }
        return isfull;
    }
    
    

    public int[] get() {
        return sensorData;
    }
    
    
}
