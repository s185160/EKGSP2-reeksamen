package ekggraphimp;

import java.time.LocalDateTime;
import java.util.ArrayList;
import javax.swing.JFrame;

public class EkgGraphImp {

    public static void main(String[] args) throws InterruptedException {
        Buffer buffer = new Buffer();
        Queue queue = new Queue(buffer);
        Sensor ekgsensor = new Sensor(queue);
        ekgsensor.start();
        
        DataBase db = new DataBase(queue);
        JFrame ramme = new JFrame("graf");
        Painter p = new Painter(queue);
        ramme.add(p);
        ramme.setContentPane(p);
        ramme.setSize(1400, 500);
        ramme.setVisible(true);
        ramme.setDefaultCloseOperation(3);
        do{
            Thread.sleep(1000);
        p.run();
        }while(true);
        
        
    }
}
